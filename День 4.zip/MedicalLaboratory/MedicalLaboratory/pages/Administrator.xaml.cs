﻿using MedicalLaboratory.database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MedicalLaboratory.pages
{
    /// <summary>
    /// Логика взаимодействия для Administrator.xaml
    /// </summary>
    public partial class Administrator : Window
    {
        private LogInSystem[] history;
        public Administrator()
        {
            InitializeComponent();
            RefreshWindow();
            cbFiltering.ItemsSource = App.laboratory.Users.Select(x => x.Login).ToList();
        }

        private LogInSystem[] FilteringLogin(LogInSystem[] history)//Фильтрация логина
        {
            try
            {
                history = history.Where(x => x.User.Login.ToLower().Contains(cbFiltering.Text.ToLower())).ToArray();
            }
            catch { }
            return history;
        }

        private LogInSystem[] SortingDate(LogInSystem[] history)//Сортировка по дате
        {
            try
            {
                switch (cbFiltering.SelectedIndex)
                {
                    case 0:
                        history = history.ToArray();
                        break;

                    case 1:
                        history = history.OrderBy(x => x.DateInput).ToArray();//по возрастанию
                        break;

                    case 2:
                        history = history.OrderByDescending(x => x.DateInput).ToArray();//по убыванию
                        break;
                }
            }
            catch { }
            return history;
        }

        private void RefreshWindow()//Вывод всех данных
        {

            history = App.laboratory.LogInSystems.ToArray();
            history = SortingDate(history);
            history = FilteringLogin(history);
            BaseLogInSystem.ItemsSource = history.ToList();
        }

        private void cbFiltering_SelectionChanged(object sender, SelectionChangedEventArgs e)//Фильтрация
        {
            RefreshWindow();
        }

        private void cbSorting_SelectionChanged(object sender, SelectionChangedEventArgs e)//Сортировка
        {
            RefreshWindow();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)//Выход
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
