﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MedicalLaboratory.pages
{
    /// <summary>
    /// Логика взаимодействия для Captcha.xaml
    /// </summary>
    public partial class Captcha : Window
    {
        public Captcha()
        {
            InitializeComponent();
            ForCaptcha();
        }

        public void ForCaptcha()//Формирование капчи
        {
            try
            {
                string cap = "1234567890qwertyuiopasdfghjklzxcvbnm";
                Random r = new Random();
                Letter1.Text = Convert.ToString(cap[r.Next(cap.Length - 1)]);
                Letter2.Text = Convert.ToString(cap[r.Next(cap.Length - 1)]);
                Letter3.Text = Convert.ToString(cap[r.Next(cap.Length - 1)]);
                Letter4.Text = Convert.ToString(cap[r.Next(cap.Length - 1)]);
                Letter1.Margin = new Thickness(r.Next(2, 20), r.Next(-20, 20), 0, 0);
                Letter2.Margin = new Thickness(r.Next(-20, 20), r.Next(-20, 20), 0, 0);
                Letter3.Margin = new Thickness(r.Next(-20, 20), r.Next(-20, 20), 0, 0);
                Letter4.Margin = new Thickness(r.Next(-20, 20), r.Next(-20, 20), 0, 0);
                Letter1.FontSize = r.Next(20, 50);
                Letter2.FontSize = r.Next(20, 50);
                Letter3.FontSize = r.Next(20, 50);
                Letter4.FontSize = r.Next(20, 50);
                for (int i = 0; i < 15; i++)
                {
                    Ellipse e = new Ellipse();
                    e.Width = r.Next(2, 10);
                    e.Height = e.Width;
                    e.Fill = new SolidColorBrush(Color.FromRgb(211, 211, 211));
                    e.Margin = new Thickness(r.Next(10, 220), r.Next(10, 120), 0, 0);
                    Noise.Children.Add(e);
                }
            }
            catch { }
        }

        int stop = 10;
        System.Windows.Threading.DispatcherTimer timer = new System.Windows.Threading.DispatcherTimer();
        private void BtnCheck_Click(object sender, RoutedEventArgs e)//Проверка капчи
        {
            if (TbUserLetter.Text != Letter1.Text + Letter2.Text + Letter3.Text + Letter4.Text)
            {
                BtnUpdate_Click(sender, e);
                TbUserLetter.Clear();
                MessageBoxResult result1 = MessageBox.Show("Captcha введена неверно!\n" +
                    "Повторите попытку!", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else
            {
                MessageBoxResult result1 = MessageBox.Show("Captcha введена верно!",
                    "Успешно!", MessageBoxButton.OK, MessageBoxImage.Information);
                this.Close();
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)//Обновление капчи
        {
            Noise.Children.Clear();
            ForCaptcha();
            TbUserLetter.Clear();
        }

        private void tbUserLetter_PreviewKeyDown(object sender, KeyEventArgs e)//Запрет на пробелы
        {
            if(e.Key == Key.Space)
            {
                e.Handled = true;
            }
        }
    }
}
