﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MedicalLaboratory.pages
{
    /// <summary>
    /// Логика взаимодействия для Assistant.xaml
    /// </summary>
    public partial class Assistant : Window
    {
        public Assistant()
        {
            InitializeComponent();
            timer.Tick += new EventHandler(timerTick);
            timer.Interval = new TimeSpan(0, 0, 0, 1);
            timer.Start();
        }
        System.Windows.Threading.DispatcherTimer timer = new System.Windows.Threading.DispatcherTimer();

        private void timerTick(object sender, EventArgs e)//Когда время вышло
        {
            int seconds = Convert.ToInt32(ForSeconds.Text);
            int minuts = Convert.ToInt32(ForMinutes.Text);
            ForMinutes.Text = minuts.ToString();
            if (seconds > 0)
            {
                seconds--;
                ForSeconds.Text = seconds.ToString();
            }
            else
            {
                if (minuts > 0)
                {
                    minuts--;
                    ForMinutes.Text = minuts.ToString();
                    seconds = 59;
                    ForSeconds.Text = seconds.ToString();
                    if (minuts == 5)
                    {
                        MessageBox.Show("До окончания сеанса осталось 5 минут");
                    }
                }
                else
                {
                    timer.Stop();
                    MainWindow mainWindow = new MainWindow();
                    mainWindow.StartTimer();
                    mainWindow.Show();
                    this.Close();
                }

            }
        }

        private void Exit_Click(object sender, RoutedEventArgs e)//Выход
        {
            timer.Stop();
            MainWindow firstWindow = new MainWindow();
            firstWindow.Show();
            this.Close();
        }
    }
}
