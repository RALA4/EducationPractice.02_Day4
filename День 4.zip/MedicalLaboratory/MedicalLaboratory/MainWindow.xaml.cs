﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Common.CommandTrees.ExpressionBuilder;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MedicalLaboratory.pages;

namespace MedicalLaboratory
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        int error = 0;
        DateTime now = DateTime.Now;//текущие дата и время  

        private void BtnAuthorization_Click(object sender, RoutedEventArgs e)//Авторизация
        {
            try
            {
                string forPasswordtxt = "";
                if (pbPasswordUser.Visibility == Visibility.Visible)
                {
                    forPasswordtxt = pbPasswordUser.Password;
                }
                else
                {
                    if (tbPasswordUser.Visibility == Visibility.Visible)
                    {
                        forPasswordtxt = tbPasswordUser.Text;
                    }
                }

                var forTypeUsers = App.laboratory.Users.FirstOrDefault(x => x.Login == tbLoginUser.Text & x.Password == forPasswordtxt);//для входа
                int codeUsers = App.laboratory.Users.Where(x => x.Login == tbLoginUser.Text & x.Password == forPasswordtxt).Select(x => x.idUsers).FirstOrDefault();
                if (tbLoginUser.Text == "" | forPasswordtxt == "")
                {
                    MessageBox.Show("Заполните все поля!");
                }
                else
                {
                    if (forTypeUsers != null)
                    {
                        switch (forTypeUsers.Type)
                        {
                            case 1://Администратор
                                Administrator administrator = new Administrator();
                                administrator.Show();
                                this.Close();
                                break;

                            case 2://Бухгалтер
                                Accountant accountant = new Accountant();
                                accountant.Show();
                                this.Close();
                                break;

                            case 3://Лаборант
                                Assistant assistant = new Assistant();
                                assistant.Show();
                                this.Close();
                                break;
                        }

                        database.EP02_Day4Entities db = new database.EP02_Day4Entities();//Для сохранения данных в таблицу Вход в систему
                        database.LogInSystem addLogInSystem = new database.LogInSystem
                        {
                            id_Users = codeUsers,
                            DateInput = now.Date,
                            InputType = "Успешно"
                        };
                        db.LogInSystems.Add(addLogInSystem);
                        db.SaveChanges();
                    }
                    else
                    {
                        if (forTypeUsers == null)
                        {
                            error++;
                            FalseUsers();
                            //Для сохранения данных при неудачном входе в систему
                            database.LogInSystem falseLogInSystem = new database.LogInSystem
                            {
                                id_Users = codeUsers,
                                InputType = "Неуспешно",
                                DateInput = now.Date
                            };
                            App.laboratory.LogInSystems.Add(falseLogInSystem);
                            App.laboratory.SaveChanges();
                        }
                    }
                }
            }
            catch { }
        }

        public void FalseUsers()//Для открытия капчи 
        {
            if(error == 1)
            {
                MessageBox.Show("Данного пользователя не существует!\nПроверьте правильность введнных вами данных!");
            }
            if (error == 2)
            {
                Captcha captcha = new Captcha();
                captcha.ShowDialog();
                error = 0;
            }
        }

        int clickPassword = 0;
        private void BtnOpenOrClosePassword_Click(object sender, RoutedEventArgs e)//Скрытие и открытие пароля
        {
            clickPassword++;
            if (clickPassword == 1)
            {
                BtnOpenOrClosePassword.Content = "🔓";
                string passwordUsertxt = pbPasswordUser.Password;
                tbPasswordUser.Text = passwordUsertxt;
                pbPasswordUser.Visibility = Visibility.Hidden;
                tbPasswordUser.Visibility = Visibility.Visible;
            }
            else
            {
                BtnOpenOrClosePassword.Content = "🔒";
                clickPassword = 0;
                string passwordUsertxt = tbPasswordUser.Text;
                pbPasswordUser.Password = passwordUsertxt;
                pbPasswordUser.Visibility = Visibility.Visible;
                tbPasswordUser.Visibility = Visibility.Hidden;
            }
        }

        int stop = 10;
        System.Windows.Threading.DispatcherTimer timer = new System.Windows.Threading.DispatcherTimer(); 
        public void StartTimer()//После окончания таймера у Лаборанта
        {
            tbLoginUser.IsEnabled = false;
            pbPasswordUser.IsEnabled = false;
            tbPasswordUser.IsEnabled = false;
            BtnAuthorization.IsEnabled = false;
            BtnOpenOrClosePassword.IsEnabled = false;
            timer.Tick += new EventHandler(timerTick);
            timer.Interval = new TimeSpan(0, 0, 1);
            timer.Start();
        }

        private void timerTick(object sender, EventArgs e)//Когда время вышло
        {
            if (stop == 0)
            {
                tbLoginUser.IsEnabled = true;
                pbPasswordUser.IsEnabled = true;
                tbPasswordUser.IsEnabled = true;
                BtnAuthorization.IsEnabled = true;
                BtnOpenOrClosePassword.IsEnabled = true;
                MessageBoxResult result1 = MessageBox.Show("Время вышло!\nВойдите в систему заново!",
                    "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                timer.Stop();
                stop = 10;
            }
            else
            {
                stop--;
            }

        }
    }
}
